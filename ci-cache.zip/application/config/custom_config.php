<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Custom Configuration
|--------------------------------------------------------------------------
| Author: Verjel Ferrer
| Date: 07/07/2014
|
*/

$ci =& get_instance();

$config['app_name']		= 'CI Cache';
$config['app_username']		= 'admin';
$config['app_password']		= 'pass';

