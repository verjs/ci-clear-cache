

<div class="navbar-default sidebar" role="navigation">
    <div class="sidebar-nav navbar-collapse">
        <ul class="nav" id="side-menu">
        
            <li>
                <a href="#" data-toggle="modal" data-target="#logoutModal"><i class="glyphicon glyphicon-floppy-remove"></i>&nbsp; Clear Cache</a>
            </li>
            
            <li>
				<a href="<?php echo site_url(); ?>/index/out"><i class="glyphicon glyphicon-log-out"></i> Logout</a>
			</li>                      
        </ul>
    </div>
    <!-- /.sidebar-collapse -->
</div>
<!-- /.navbar-static-side -->
